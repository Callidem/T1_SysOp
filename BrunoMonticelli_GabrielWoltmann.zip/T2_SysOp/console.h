#ifndef CONSOLE_H
#define CONSOLE_H

#include "hardware.h"

#define CONSOLE_QUEUE_MAX 32

// Pedido de IO pendente
typedef struct {
    int pid;        // PID do processo que fez o pedido
    int op;         // 1=IN (leitura do usuário), 2=OUT (escrita na tela)
    int phys_addr;  // endereço FÍSICO da memória envolvida
} IORequest;

// Inicializa a thread Console com referência à CPU e à memória
void console_init(CPU *cpu, Memory *mem);

// Encerra a thread Console
void console_shutdown(void);

// Encosta um pedido de IO na fila (chamado pelo escalonador)
int console_enqueue(IORequest req);

// Aguarda a thread Console terminar
void console_join(void);

int  console_read_pending(int *outPid);
void console_deliver_line(const char *line);

#endif // CONSOLE_H
