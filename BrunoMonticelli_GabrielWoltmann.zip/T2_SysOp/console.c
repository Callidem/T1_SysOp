#include "console.h"
#include "scheduler.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static IORequest   queue[CONSOLE_QUEUE_MAX];
static int         q_head = 0;
static int         q_tail = 0;
static int         q_size = 0;

static pthread_mutex_t qMutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  qCond  = PTHREAD_COND_INITIALIZER;

//pedido de leitura para a shell
static pthread_mutex_t readMutex     = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  readCond      = PTHREAD_COND_INITIALIZER;
static int             readPending   = 0;   // 1 = Console aguarda uma linha
static int             readPid       = -1;  // PID do processo aguardando
static char             readLine[64] = {0};
static int              readReady    = 0;   // 1 = Shell já entregou a linha

static CPU    *sharedCpu = NULL;
static Memory *sharedMem = NULL;
static int     running   = 1;
static pthread_t consoleThread;

//api usada pela shell
// Retorna 1 se tem um pedido de IN pendente do console (a Shell deve então
// tratar a próxima linha lida como resposta de IO, não como comando).
int console_read_pending(int *outPid) {
    pthread_mutex_lock(&readMutex);
    int p = readPending;
    if (p && outPid) *outPid = readPid;
    pthread_mutex_unlock(&readMutex);
    return p;
}

// Chamado pela Shell quando ela tem uma linha que deve ir para o Console
void console_deliver_line(const char *line) {
    pthread_mutex_lock(&readMutex);
    strncpy(readLine, line, sizeof(readLine) - 1);
    readLine[sizeof(readLine) - 1] = '\0';
    readReady = 1;
    readPending = 0;
    pthread_cond_signal(&readCond);
    pthread_mutex_unlock(&readMutex);
}

//thread console
static void *console_loop(void *arg) {
    (void)arg;
    while (1) {
        pthread_mutex_lock(&qMutex);
        while (q_size == 0 && running)
            pthread_cond_wait(&qCond, &qMutex);
        if (!running && q_size == 0) { pthread_mutex_unlock(&qMutex); break; }
        IORequest req = queue[q_head];
        q_head = (q_head + 1) % CONSOLE_QUEUE_MAX;
        q_size--;
        pthread_mutex_unlock(&qMutex);

        if (req.op == 1) {
            // ----  IN: pede à Shell que repasse a próxima linha digitada  ----
            printf("\n[console] PID %d aguardando entrada (digite um valor): ",
                   req.pid);
            fflush(stdout);

            pthread_mutex_lock(&readMutex);
            readPending = 1;
            readPid     = req.pid;
            readReady   = 0;
            while (!readReady && running)
                pthread_cond_wait(&readCond, &readMutex);
            char line[64];
            strncpy(line, readLine, sizeof(line));
            pthread_mutex_unlock(&readMutex);

            int val = 0;
            if (sscanf(line, "%d", &val) == 1) {
                if (req.phys_addr >= 0 && (size_t)req.phys_addr < sharedMem->size) {
                    sharedMem->pos[req.phys_addr].opc = DATA;
                    sharedMem->pos[req.phys_addr].p   = val;
                    printf("[console] IN concluido: mem[%d] = %d  (PID %d)\n",
                           req.phys_addr, val, req.pid);
                } else {
                    printf("[console] ENDERECO INVALIDO na leitura (PID %d)\n", req.pid);
                }
            } else {
                printf("[console] FALHA NA LEITURA (PID %d) - valor invalido\n", req.pid);
            }

        } else if (req.op == 2) {
            //OUT: não precisa de stdin, só escreve na tela
            if (req.phys_addr >= 0 && (size_t)req.phys_addr < sharedMem->size) {
                printf("[console] OUT PID %d: %d\n",
                       req.pid, sharedMem->pos[req.phys_addr].p);
            } else {
                printf("[console] ENDERECO INVALIDO na escrita (PID %d)\n", req.pid);
            }
        }

        // Interrompe a CPU: IO concluído, processo pode voltar para READY
        sharedCpu->ioReturnPid = req.pid;
        sharedCpu->intIO = 1;
        scheduler_notify_work();   // acorda imediatamente a Thread Escalonador
    }
    return NULL;
}

void console_init(CPU *cpu, Memory *mem) {
    sharedCpu = cpu; sharedMem = mem; running = 1;
    q_head = q_tail = q_size = 0;
    readPending = readReady = 0;
    if (pthread_create(&consoleThread, NULL, console_loop, NULL) != 0) {
        fprintf(stderr, "Erro ao criar thread Console\n"); exit(EXIT_FAILURE);
    }
}

int console_enqueue(IORequest req) {
    pthread_mutex_lock(&qMutex);
    if (q_size >= CONSOLE_QUEUE_MAX) { pthread_mutex_unlock(&qMutex); return 0; }
    queue[q_tail] = req;
    q_tail = (q_tail + 1) % CONSOLE_QUEUE_MAX;
    q_size++;
    pthread_cond_signal(&qCond);
    pthread_mutex_unlock(&qMutex);
    return 1;
}

void console_shutdown(void) {
    pthread_mutex_lock(&qMutex);
    running = 0;
    pthread_cond_signal(&qCond);
    pthread_mutex_unlock(&qMutex);

    // Acorda também qualquer leitura pendente, para não travar o join
    pthread_mutex_lock(&readMutex);
    pthread_cond_broadcast(&readCond);
    pthread_mutex_unlock(&readMutex);
}

void console_join(void) { pthread_join(consoleThread, NULL); }
