#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <unistd.h>

#include "hardware.h"
#include "so.h"
#include "programs.h"
#include "utils.h"
#include "gp.h"
#include "gm.h"
#include "scheduler.h"
#include "console.h"

int main(void) {
    CPU    cpu;
    Memory mem;
    GM     gm;

    //CONFIGURAÇÃO
    int tamPg  = 8;
    int tamMem = 1024;

    printf("Tamanho da pagina (palavras) [%d]: ", tamPg);
    fflush(stdout);
    {
        char buf[32];
        if (fgets(buf, sizeof(buf), stdin) && buf[0] != '\n')
            sscanf(buf, "%d", &tamPg);
    }
    printf("Tamanho da memoria (palavras) [%d]: ", tamMem);
    fflush(stdout);
    {
        char buf[32];
        if (fgets(buf, sizeof(buf), stdin) && buf[0] != '\n')
            sscanf(buf, "%d", &tamMem);
    }

    memory_init(&mem, (size_t)tamMem);
    cpu_init(&cpu, &mem, 0);
    gm_init(&gm, &mem, tamPg);
    cpu_set_handlers(&cpu, so_interrupt_handle, so_syscall_handle, so_syscall_stop);
    cpu_set_gm(&cpu, &gm);

    // Dispara threads: Escalonador, CPU e Console (dispositivo de IO)
    scheduler_init(&cpu, &gm, &mem);
    console_init(&cpu, &mem);

    printf("\nSO iniciado. Threads ativas: Shell | Escalonador | CPU | Console\n");
    printf("Comandos: new <prog>, ps, dump <id>, dumpM <ini> <fim>,\n");
    printf("          rm <id>, traceOn, traceOff, exit\n\n");
    printf("Programas disponiveis: fatorial, fatorialV2, progMinimo,\n");
    printf("  fibonacci10, fibonacci10v2, fibonacciREAD, PB, PC\n\n");

       char linha[256];
    int  promptShown = 0;

    while (1) {
        if (!promptShown) {
            printf("so> ");
            fflush(stdout);
            promptShown = 1;
        }

        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);
        struct timeval tv = { 0, 100000 }; // 100ms

        int sel = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
        if (sel < 0) break;
        if (sel == 0) continue; // timeout: nada digitado ainda, tenta de novo

        if (!fgets(linha, sizeof(linha), stdin)) break;
        linha[strcspn(linha, "\n")] = '\0';
        promptShown = 0;
        if (linha[0] == '\0') continue;

        bool isComando =
            strncmp(linha, "new ", 4)   == 0 ||
            strcmp (linha, "ps")        == 0 ||
            strncmp(linha, "dump ", 5)  == 0 ||
            strncmp(linha, "dumpM", 5)  == 0 ||
            strncmp(linha, "rm ", 3)    == 0 ||
            strcmp (linha, "traceOn")   == 0 ||
            strcmp (linha, "traceOff")  == 0 ||
            strcmp (linha, "exit")      == 0;

        int waitingPid = -1;
        if (!isComando && console_read_pending(&waitingPid)) {
            console_deliver_line(linha);
            continue;
        }

        // new<prog>
        // Cria processo e coloca ele na fila de prontos imediatamente.
        // O escalonador detecta ele e começa a escalonar sem nenhum comando adicional.
        if (strncmp(linha, "new ", 4) == 0) {
            char nome[128];
            if (sscanf(linha + 4, "%127s", nome) != 1) {
                printf("Uso: new <nomeDePrograma>\n"); continue;
            }
            const Program *prog = retrieve_program(nome);
            if (!prog) { printf("Programa nao encontrado: %s\n", nome); continue; }

            // Cria PCB e aloca paginas
            PCB *pcb = criaProcesso((Program *)prog, &gm);
            if (!pcb) { printf("Falha ao criar processo (sem memoria?)\n"); continue; }

            // Carrega programa na memoria fisica
            utils_load_program(&mem, &gm, pcb->pageTable, pcb->numPages,
                               prog->size, prog->image);

            pcb->state = READY;

            // Loga criação ANTES de adicionar ao escalonador
            so_log_transicao(pcb, "criacao", NEW, READY);
            printf("Processo criado: PID %d (%s)\n", pcb->pid, prog->name);

            // Adiciona ao escalonador -> acorda Thread Escalonador
            scheduler_add(pcb);
            continue;
        }

        // ---- ps ----
        if (strcmp(linha, "ps") == 0) {
            scheduler_lock();
            int total = scheduler_count();
            if (total == 0) {
                printf("Nenhum processo na fila de prontos\n");
            } else {
                printf("%-5s %-16s %-12s %-5s\n", "PID", "Programa", "Estado", "PC");
                printf("%-5s %-16s %-12s %-5s\n", "---", "-------", "------", "--");
                for (int i = 0; i < total; ++i) {
                    PCB *p = scheduler_get(i);
                    if (!p) continue;
                    const char *st;
                    switch (p->state) {
                        case NEW:        st = "NEW";        break;
                        case READY:      st = "READY";      break;
                        case RUNNING:    st = "RUNNING";    break;
                        case BLOCKED:    st = "BLOCKED";    break;
                        case TERMINATED: st = "TERMINATED"; break;
                        default:         st = "?";
                    }
                    printf("%-5d %-16s %-12s %-5d\n",
                           p->pid, p->prog ? p->prog->name : "?", st, p->pc);
                }
            }
            scheduler_unlock();
            continue;
        }

        // dump<id>
        if (strncmp(linha, "dump ", 5) == 0) {
            int pid;
            if (sscanf(linha + 5, "%d", &pid) != 1) {
                printf("Uso: dump <id>\n"); continue;
            }
            scheduler_lock();
            PCB *p = scheduler_find_pcb(pid);
            if (!p) {
                printf("PID %d nao encontrado\n", pid);
            } else {
                scheduler_dump_pcb(p);
                scheduler_dump_process_memory(p);
            }
            scheduler_unlock();
            continue;
        }

        //dumpM<ini><fim>
        if (strncmp(linha, "dumpM", 5) == 0) {
            int ini, fim;
            if (sscanf(linha + 5, "%d %d", &ini, &fim) != 2 &&
                sscanf(linha + 5, "%d,%d", &ini, &fim) != 2) {
                printf("Uso: dumpM <inicio> <fim>\n"); continue;
            }
            if (ini < 0) ini = 0;
            if (fim < ini) { printf("Intervalo invalido\n"); continue; }
            scheduler_lock();
            utils_dump_mem(&mem, ini, fim + 1);
            scheduler_unlock();
            continue;
        }

        //  rm<id> 
        if (strncmp(linha, "rm ", 3) == 0) {
            int pid;
            if (sscanf(linha + 3, "%d", &pid) != 1) {
                printf("Uso: rm <id>\n"); continue;
            }
            scheduler_lock();
            int idx = scheduler_find_idx(pid);
            if (idx < 0) {
                printf("PID %d nao encontrado (pode estar bloqueado ou ja terminou)\n", pid);
                scheduler_unlock();
                continue;
            }
            PCB *p = scheduler_get(idx);
            if (p->state == RUNNING) {
                p->killRequested = 1;
                printf("PID %d marcado para remocao\n", pid);
            } else {
                scheduler_remove_at_idx(idx);
                printf("PID %d removido\n", pid);
            }
            scheduler_unlock();
            continue;
        }

        // ---- traceOn / traceOff ----
        if (strcmp(linha, "traceOn") == 0) {
            scheduler_lock();
            cpu.debug = 1;
            scheduler_unlock();
            printf("Trace ligado\n");
            continue;
        }
        if (strcmp(linha, "traceOff") == 0) {
            scheduler_lock();
            cpu.debug = 0;
            scheduler_unlock();
            printf("Trace desligado\n");
            continue;
        }

        // ---- exit ----
        if (strcmp(linha, "exit") == 0) break;

        printf("Comando desconhecido: '%s'\n", linha);
    }

    //ENCERRAMENTO
    printf("\nEncerrando SO...\n");
    scheduler_shutdown();
    scheduler_join();
    console_shutdown();
    console_join();

    free(gm.framesAlocados);
    memory_free(&mem);
    printf("SO encerrado.\n");
    return 0;
}
