#ifndef SO_H
#define SO_H

#include "hardware.h"
#include "gp.h"

//LOG DE MUDANCA DE ESTADO
// Registra toda transição de estado de processo conforme o enunciado.
// Formato: ID | NomeProg | Razao | EstadoAnterior | ProximoEstado | TabelaDePaginas
void so_log_transicao(const PCB *pcb, const char *razao,
                      int estado_de, int estado_para);

//HANDLERS DA CPU
void so_interrupt_handle(CPU *cpu, Interrupts irpt);
void so_syscall_handle(CPU *cpu);
void so_syscall_stop(CPU *cpu);

//CONTEXTO GLOBAL DO SO
// O SO precisa de acesso ao processo que está rodando para tratar SYSCALL IO.
// O escalonador seta isso antes de cada quantum.
void so_set_running(PCB *pcb);
PCB *so_get_running(void);

// Flag que o syscall IO seta para indicar ao escalonador que deve bloquear o processo
extern int so_io_requested;     // 1 se o processo atual fez IO
extern int so_io_op;            // 1=IN, 2=OUT
extern int so_io_addr;          // endereço lógico do IO

#endif // SO_H
