#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdbool.h>
#include "gp.h"
#include "hardware.h"
#include "gm.h"

// Inicializa o escalonador e dispara as threads CPU e Escalonador
void scheduler_init(CPU *cpu, GM *gm, Memory *mem);

// Encerra as threads do escalonador
void scheduler_shutdown(void);
void scheduler_join(void);

// Adiciona um PCB à fila de prontos
int  scheduler_add(PCB *pcb);

// Busca e remoção de processos
PCB *scheduler_find_pcb(int pid);
int  scheduler_find_idx(int pid);
void scheduler_remove_at_idx(int idx);

// Utilitários de listagem/dump
int   scheduler_count(void);
PCB  *scheduler_get(int index);
void  scheduler_dump_pcb(const PCB *pcb);
void  scheduler_dump_process_memory(const PCB *pcb);

// Acesso protegido ao mutex global do escalonador (usado pelo main)
void scheduler_lock(void);
void scheduler_unlock(void);

// Chamado pela Thread Console quando um IO é concluído, para acordar
// imediatamente a Thread Escalonador (que pode estar dormindo em condWork).
void scheduler_notify_work(void);

#endif // SCHEDULER_H
