#include "scheduler.h"
#include "so.h"
#include "console.h"
#include "utils.h"
#include "gm.h"

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <time.h>

#define MAX_PROCESSOS 64
#define QUANTUM       5

// ESTADO GLOBAL
static CPU    *sharedCpu = NULL;
static GM     *sharedGm  = NULL;
static Memory *sharedMem = NULL;

// Fila de prontos
static PCB *prontos[MAX_PROCESSOS] = {0};
static int  totalProntos = 0;
static int  schedIndex   = 0;

// Fila de bloqueados (aguardando IO)
static PCB *bloqueados[MAX_PROCESSOS] = {0};
static int  totalBloqueados = 0;

static bool systemExit = false;

// Mutex único protege todas as filas e flags compartilhadas
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Sinaliza ao Escalonador que há trabalho a avaliar
static pthread_cond_t condWork = PTHREAD_COND_INITIALIZER;

// Sinaliza à Thread CPU que pode iniciar o próximo quantum
static pthread_cond_t condCpuGo = PTHREAD_COND_INITIALIZER;
static bool cpuShouldRun = false;

// Sinaliza ao Escalonador que a CPU terminou o quantum
static pthread_cond_t condCpuDone = PTHREAD_COND_INITIALIZER;
static bool cpuDone = false;

static pthread_t threadEscalonador;
static pthread_t threadCPU;

//HELPERS INTERNOS

static const char *state_name(int s) {
    switch (s) {
        case NEW:        return "NEW";
        case READY:      return "READY";
        case RUNNING:    return "RUNNING";
        case BLOCKED:    return "BLOCKED";
        case TERMINATED: return "TERMINATED";
        default:         return "?";
    }
}

// Escolhe próximo READY em Round-Robin (chamado com mutex travado)
static PCB *pick_next_ready(void) {
    for (int a = 0; a < totalProntos; ++a) {
        int idx = (schedIndex + a) % totalProntos;
        PCB *p  = prontos[idx];
        if (p && p->state == READY) {
            schedIndex = (idx + 1) % totalProntos;
            return p;
        }
    }
    return NULL;
}

static bool has_ready(void) {
    for (int i = 0; i < totalProntos; ++i)
        if (prontos[i] && prontos[i]->state == READY) return true;
    return false;
}

static bool has_work(void) {
    // Há trabalho se: existe pronto para rodar, OU a CPU sinalizou
    // retorno de IO que ainda não foi tratado, OU o sistema está saindo.
    return systemExit || has_ready() || sharedCpu->intIO;
}

static void remove_from_prontos(int idx) {
    if (idx < 0 || idx >= totalProntos) return;
    for (int i = idx; i < totalProntos - 1; ++i)
        prontos[i] = prontos[i + 1];
    prontos[--totalProntos] = NULL;
    if (schedIndex >= totalProntos && totalProntos > 0) schedIndex = 0;
}

static int find_prontos_idx(int pid) {
    for (int i = 0; i < totalProntos; ++i)
        if (prontos[i] && prontos[i]->pid == pid) return i;
    return -1;
}

static PCB *remove_from_bloqueados(int pid) {
    for (int i = 0; i < totalBloqueados; ++i) {
        if (bloqueados[i] && bloqueados[i]->pid == pid) {
            PCB *p = bloqueados[i];
            for (int j = i; j < totalBloqueados - 1; ++j)
                bloqueados[j] = bloqueados[j + 1];
            bloqueados[--totalBloqueados] = NULL;
            return p;
        }
    }
    return NULL;
}

// Trata um retorno de IO pendente sinalizado pela CPU (chamado com mutex travado)
static void handle_io_return_locked(void) {
    if (!sharedCpu->intIO) return;

    int pid = sharedCpu->ioReturnPid;
    sharedCpu->intIO = 0;
    sharedCpu->ioReturnPid = -1;

    PCB *bloq = remove_from_bloqueados(pid);
    if (bloq) {
        bloq->state = READY;
        prontos[totalProntos++] = bloq;
        so_log_transicao(bloq, "retorno de IO", BLOCKED, READY);
    }
}

//THREAD CPU
static void *cpu_thread(void *arg) {
    (void)arg;
    while (1) {
        pthread_mutex_lock(&mutex);
        while (!cpuShouldRun && !systemExit)
            pthread_cond_wait(&condCpuGo, &mutex);
        if (systemExit) { pthread_mutex_unlock(&mutex); break; }
        cpuShouldRun = false;
        pthread_mutex_unlock(&mutex);

        // Executa o quantum SEM segurar o mutex (permite que outras
        // threads — ex.: Console sinalizando intIO — acessem o estado)
        cpu_run_steps(sharedCpu, QUANTUM);

        pthread_mutex_lock(&mutex);
        cpuDone = true;
        pthread_cond_signal(&condCpuDone);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

//THREAD ESCALONADOR
static void *scheduler_thread(void *arg) {
    (void)arg;

    while (1) {
        pthread_mutex_lock(&mutex);

        while (!has_work())
            pthread_cond_wait(&condWork, &mutex);

        if (systemExit) { pthread_mutex_unlock(&mutex); break; }

        // Trata retorno de IO pendente (se houver) antes de escalonar
        handle_io_return_locked();

        PCB *pcb = pick_next_ready();
        if (!pcb) {
            // Nada pronto agora (só bloqueados aguardando IO) — aguarda novo evento
            pthread_mutex_unlock(&mutex);
            continue;
        }

        int prev_state = pcb->state;
        pcb->state = RUNNING;
        so_set_running(pcb);

        cpu_set_page_table(sharedCpu, pcb->pageTable, pcb->numPages);
        recup_contexto(sharedCpu, pcb);
        sharedCpu->cpuStop = 0;
        sharedCpu->irpt    = noInterrupt;
        sharedCpu->intIO   = 0;

        const char *razao = (prev_state == NEW) ? "criacao" : "escalona.";
        so_log_transicao(pcb, razao, prev_state, RUNNING);
        printf("\n[sch] PID %d (%s) -> CPU (quantum %d)\n",
               pcb->pid, pcb->prog ? pcb->prog->name : "?", QUANTUM);
        fflush(stdout);

        // Libera a Thread CPU e aguarda especificamente o quantum terminar
        cpuDone = false;
        cpuShouldRun = true;
        pthread_cond_signal(&condCpuGo);
        while (!cpuDone)
            pthread_cond_wait(&condCpuDone, &mutex);
        cpuDone = false;

        //PÓS-QUANTUM
        PCB *cur = so_get_running();
        so_set_running(NULL);

        if (!cur) { pthread_mutex_unlock(&mutex); continue; }

        if (so_io_requested) {
            // Processo pediu IO: bloqueia e despacha pedido ao dispositivo
            so_io_requested = 0;
            int phys = end_fisico(sharedGm, cur->pageTable, cur->numPages, so_io_addr);

            salva_contexto(sharedCpu, cur);
            cur->state = BLOCKED;
            so_log_transicao(cur, "solicita IO", RUNNING, BLOCKED);

            int idx = find_prontos_idx(cur->pid);
            if (idx >= 0) remove_from_prontos(idx);
            bloqueados[totalBloqueados++] = cur;

            IORequest req = { .pid = cur->pid, .op = so_io_op, .phys_addr = phys };
            console_enqueue(req);

            pthread_mutex_unlock(&mutex);
            continue;
        }

        if (sharedCpu->intIO) {
            // Outro processo teve IO concluído enquanto este rodava:
            // este processo perde a fatia de tempo (interrompido), volta para READY,
            // e o que retornou de IO entra em prontos.
            int pid = sharedCpu->ioReturnPid;
            sharedCpu->intIO = 0;
            sharedCpu->ioReturnPid = -1;
            sharedCpu->irpt = noInterrupt;

            salva_contexto(sharedCpu, cur);
            cur->state = READY;
            so_log_transicao(cur, "fatia tempo", RUNNING, READY);

            PCB *bloq = remove_from_bloqueados(pid);
            if (bloq) {
                bloq->state = READY;
                prontos[totalProntos++] = bloq;
                so_log_transicao(bloq, "retorno de IO", BLOCKED, READY);
            }

            pthread_mutex_unlock(&mutex);
            continue;
        }

        bool terminou = cur->killRequested
                     || sharedCpu->cpuStop
                     || sharedCpu->irpt != noInterrupt
                     || sharedCpu->ir.opc == STOP;

        if (terminou) {
            so_log_transicao(cur, "terminou", RUNNING, TERMINATED);
            printf("[sch] PID %d (%s) terminou\n",
                   cur->pid, cur->prog ? cur->prog->name : "?");

            // Especificação T2: NÃO apagar o conteúdo da memória ao terminar.
            // Apenas desaloca PCB e frames (libera para reuso), preservando
            // o conteúdo físico para que `dump`/`dumpM` mostrem o resultado.
            int idx = find_prontos_idx(cur->pid);
            if (idx >= 0) remove_from_prontos(idx);

            desaloca(cur->pageTable, cur->numPages, sharedGm);
            free(cur->pageTable);
            free(cur);
        } else {
            salva_contexto(sharedCpu, cur);
            cur->state = READY;
            so_log_transicao(cur, "fatia tempo", RUNNING, READY);
        }

        if (!has_ready() && totalBloqueados == 0) {
            printf("\n[sch] todos os processos terminaram\n");
        }

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

//INTERFACE PÚBLICA

void scheduler_init(CPU *cpu, GM *gm, Memory *mem) {
    sharedCpu = cpu;
    sharedGm  = gm;
    sharedMem = mem;

    if (pthread_create(&threadCPU, NULL, cpu_thread, NULL) != 0) {
        fprintf(stderr, "Erro ao criar thread CPU\n");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&threadEscalonador, NULL, scheduler_thread, NULL) != 0) {
        fprintf(stderr, "Erro ao criar thread Escalonador\n");
        exit(EXIT_FAILURE);
    }
}

void scheduler_shutdown(void) {
    pthread_mutex_lock(&mutex);
    systemExit = true;
    pthread_cond_broadcast(&condWork);
    pthread_cond_broadcast(&condCpuGo);
    pthread_cond_broadcast(&condCpuDone);
    pthread_mutex_unlock(&mutex);
}

void scheduler_join(void) {
    pthread_join(threadEscalonador, NULL);
    pthread_join(threadCPU, NULL);
}

int scheduler_add(PCB *pcb) {
    pthread_mutex_lock(&mutex);
    if (totalProntos >= MAX_PROCESSOS) {
        pthread_mutex_unlock(&mutex);
        return -1;
    }
    prontos[totalProntos++] = pcb;
    pthread_cond_signal(&condWork);
    pthread_mutex_unlock(&mutex);
    return totalProntos - 1;
}

PCB *scheduler_find_pcb(int pid) {
    for (int i = 0; i < totalProntos; ++i)
        if (prontos[i] && prontos[i]->pid == pid) return prontos[i];
    for (int i = 0; i < totalBloqueados; ++i)
        if (bloqueados[i] && bloqueados[i]->pid == pid) return bloqueados[i];
    return NULL;
}

int scheduler_find_idx(int pid) {
    for (int i = 0; i < totalProntos; ++i)
        if (prontos[i] && prontos[i]->pid == pid) return i;
    return -1;
}

void scheduler_remove_at_idx(int idx) {
    pthread_mutex_lock(&mutex);
    if (idx >= 0 && idx < totalProntos) {
        desalocaProcesso(prontos[idx], sharedGm);
        remove_from_prontos(idx);
    }
    pthread_mutex_unlock(&mutex);
}

int   scheduler_count(void) { return totalProntos; }
PCB  *scheduler_get(int i)  { return (i >= 0 && i < totalProntos) ? prontos[i] : NULL; }

void scheduler_lock(void)   { pthread_mutex_lock(&mutex); }
void scheduler_unlock(void) { pthread_mutex_unlock(&mutex); }

void scheduler_notify_work(void) {
    pthread_mutex_lock(&mutex);
    pthread_cond_signal(&condWork);
    pthread_mutex_unlock(&mutex);
}

void scheduler_dump_pcb(const PCB *pcb) {
    if (!pcb) return;
    printf("PID: %d\n", pcb->pid);
    printf("Programa: %s\n", pcb->prog ? pcb->prog->name : "?");
    printf("Estado: %s\n", state_name(pcb->state));
    printf("PC: %d\n", pcb->pc);
    printf("Paginas: %d\n", pcb->numPages);
    printf("Tabela de paginas:\n");
    for (int i = 0; i < pcb->numPages; ++i)
        printf("  [%d] = frame %d\n", i, pcb->pageTable[i]);
    printf("Registradores:\n");
    for (int i = 0; i < 10; ++i)
        printf("  r[%d] = %d\n", i, pcb->regs[i]);
}

void scheduler_dump_process_memory(const PCB *pcb) {
    if (!pcb || !sharedGm || !sharedMem) return;
    for (int i = 0; i < pcb->numPages; ++i) {
        int frame = pcb->pageTable[i];
        if (frame < 0) continue;
        int ini = frame * sharedGm->tamPg;
        int fim = ini + sharedGm->tamPg;
        printf("  pagina %d -> frame %d  (end. fisicos %d..%d)\n",
               i, frame, ini, fim - 1);
        utils_dump_mem(sharedMem, ini, fim);
    }
}
