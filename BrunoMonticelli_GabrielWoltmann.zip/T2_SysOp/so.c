#include "so.h"
#include <stdio.h>
#include <string.h>

//CONTEXTO GLOBAL
static PCB *runningPcb = NULL;

int so_io_requested = 0;
int so_io_op        = 0;
int so_io_addr      = 0;

void so_set_running(PCB *pcb) { runningPcb = pcb; }
PCB *so_get_running(void)     { return runningPcb; }

//NOMES DOS ESTADOS
static const char *state_str(int s) {
    switch (s) {
        case NEW:        return "novo";
        case READY:      return "pronto";
        case RUNNING:    return "rodando";
        case BLOCKED:    return "bloqueado";
        case TERMINATED: return "terminado";
        default:         return "?";
    }
}

//LOG DE TRANSCRIÇÃO
// Exibido a cada mudança de estado:
// ID | Nome | Razao | Estado_de | Estado_para | [{pag,frame}...]
void so_log_transicao(const PCB *pcb, const char *razao,
                      int estado_de, int estado_para) {
    if (!pcb) return;

    // Monta string da tabela de páginas: { [pag,frame], ... }
    char tabela[512] = "{ ";
    for (int i = 0; i < pcb->numPages; ++i) {
        char buf[32];
        snprintf(buf, sizeof(buf), "[%d,%d]%s",
                 i, pcb->pageTable[i],
                 (i < pcb->numPages - 1) ? ", " : "");
        strncat(tabela, buf, sizeof(tabela) - strlen(tabela) - 1);
    }
    strncat(tabela, " }", sizeof(tabela) - strlen(tabela) - 1);

    printf("[SO] %3d | %-14s | %-16s | %-10s -> %-10s | %s\n",
           pcb->pid,
           pcb->prog ? pcb->prog->name : "?",
           razao,
           state_str(estado_de),
           state_str(estado_para),
           tabela);
    fflush(stdout);
}

//TRATADOR DE INTERRUPÇÃO
// Chamado pela CPU quando ocorre intEnderecoInvalido, intOverflow, etc.
// Para intRetornoIO: o escalonador trata diretamente (não passa por aqui).
void so_interrupt_handle(CPU *cpu, Interrupts irpt) {
    (void)cpu;
    switch (irpt) {
        case intEnderecoInvalido:
            printf("[SO] Interrupcao: endereco invalido\n");
            break;
        case intInstrucaoInvalida:
            printf("[SO] Interrupcao: instrucao invalida\n");
            break;
        case intOverflow:
            printf("[SO] Interrupcao: overflow\n");
            break;
        case intRetornoIO:
            // Tratado pelo escalonador ao detectar cpu->intIO
            break;
        default:
            printf("[SO] Interrupcao desconhecida: %d\n", irpt);
            break;
    }
}

//SYSCALL STOP
void so_syscall_stop(CPU *cpu) {
    (void)cpu;
    // O escalonador detecta o STOP e loga a transição
    printf("[SO] SYSCALL STOP\n");
}

//SYSCALL IO (ASSINCRONA)
void so_syscall_handle(CPU *cpu) {
    int op   = cpu->reg[8];
    int addr = cpu->reg[9];

    so_io_op   = op;
    so_io_addr = addr;
    so_io_requested = 1;

    cpu->cpuStop = 1;
}
