#ifndef PROGRAMS_H
#define PROGRAMS_H

#include "hardware.h"

// Estrutura de um programa
// name:  nome identificador do programa
// image: array de Words contendo as instruções do programa
// size:  número de instruções do programa
typedef struct {
    const char *name;
    const Word *image;
    int size;
} Program;

// Recupera um programa pelo nome
// Retorna pointer para a estrutura Program ou NULL se não encontrado
const Program *retrieve_program(const char *name);

#endif // PROGRAMS_H
